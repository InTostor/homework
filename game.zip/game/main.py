mainPath = str(__file__).replace("main.py", "")
levelsPath = mainPath+"\\levels\\"
print(mainPath)

import keyboard
from termcolor import colored, cprint
import os
from levelparser import *

clear = lambda: os.system('cls')
block_keyboard=False
levelCount = 1

objects = (" -", " #", "out"," ♥","!")

class Level(object):
    levelArr=[]
    def __init__(self, id):
        """Constructor"""
        self.id=id
        self.getLevel(id)

    def getLevel(self,id):
        self.levelArr = getLevel(levelsPath+"level"+str(id)+".lvl")

    def delPickup(self,pos):
        x,y=pos[0],pos[1]
        self.levelArr[x][y]=0

    
level = Level(levelCount)

class Player(object):
    """docstring"""
 
    def __init__(self, icon,pos,maxHp,hp,maxarmor,armor):
        """Constructor"""
        self.icon=icon
        self.pos=pos
        self.maxHp=maxHp
        self.hp=hp
        self.maxarmor=maxarmor
        self.armor=armor
    

    def pickup(self,item,pos):
        if item==3:
            self.hp=self.hp+10

        level.delPickup(pos)

    def setPlayerIcon(self):
        if self.hp>self.maxHp/2:
            self.icon= "😎"
        if self.hp<self.maxHp/2 and self.hp> self.maxHp/4:
            self.icon= "😃"
        if self.hp<self.maxHp/4 :
            self.icon= "😒"


player=Player("😃",[5, 5],200,10,100,10)

# playerIcon="😃"
# playerPos = [5, 5]
# playerMaxHp=200
# playerHp=10
# playerArmor=10

# level = [
#     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
#     [1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
#     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
#     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2],
#     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
#     [1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1],
#     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
#     [1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
#     [1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1],
#     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
# ]

# level = getLevel(levelsPath+"level"+str(levelCount)+".lvl")



blocking = [1,228]

def clamp(n, smallest, largest): return max(smallest, min(n, largest))



def wasdCoords(pos):
    # interrupts code
    
    while True:
        global block_keyboard
        w=keyboard.is_pressed('w')
        a=keyboard.is_pressed('a')
        s=keyboard.is_pressed('s')
        d=keyboard.is_pressed('d')
        if not( w|a|s|d):
            block_keyboard=False
        if block_keyboard:
            break
  

        if w :
            x,y=pos[1]-1,pos[0]
            near = level.levelArr[x][y]
            player.pickup(near,[x,y])
            if not near in blocking:            
                pos[1]-=1
            block_keyboard=True
            break
        if a:
            x,y=pos[1],pos[0]-1
            near = level.levelArr[x][y]
            player.pickup(near,[x,y])
            if not near in blocking:
                pos[0]-=1
            block_keyboard=True
            break
        if s:
            x,y=pos[1]+1,pos[0]
            near = level.levelArr[x][y]
            player.pickup(near,[x,y])
            print(near)
            if not near in blocking:
                pos[1]+=1
            block_keyboard=True
            break
        if d:
            x,y=pos[1],pos[0]+1
            near = level.levelArr[x][y]
            player.pickup(near,[x,y])
            if not near in blocking:
                pos[0]+=1
            block_keyboard=True
            break

    return pos


def numToSymbol(lst):
    out = []
    for i in range(0, len(lst)):
        out.append(objects[lst[i]])
    return out[::1]

def drawLevel(lvl,pos):
    
    out=[]
    for i in range(0,len(lvl)):
        out.append(numToSymbol(lvl[i]))
    
    x,y=pos[1],pos[0]
    x,y=clamp(x,0,8),clamp(y,0,len(lvl[0])-1)
    out[x][y]=player.icon
    outstr=""
    for i in range(0,len(lvl)):
        outstr = outstr+"".join(out[i])+"\n"
        # print(" ".join(out[i]))
    print(outstr)
    return out

while True:
    clear()
    player.setPlayerIcon()
    print("*"*30)
    print("❤ :",player.hp,"🛡 :",player.armor)
    print("*"*30)
    drawLevel(level.levelArr,player.pos)
    player.pos =wasdCoords(player.pos)