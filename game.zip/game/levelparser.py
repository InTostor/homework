

def getLevel(path):
    with open(path, "r") as file:
        levelArr = [[int(x) for x in line.split()] for line in file]
    return levelArr
